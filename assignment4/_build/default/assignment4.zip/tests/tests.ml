(*
  Put the tests for lib.ml functions here
*)

open Core;;
open OUnit2;;
